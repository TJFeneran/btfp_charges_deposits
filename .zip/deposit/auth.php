<?php
	$merchantAuthentication->setName("9Kq4wbk5WU3S");
	$merchantAuthentication->setTransactionKey("9g5c582PNKmL2e2m");
?>
