<?php
	//DEFAULT: MYBTF STORE // JUMP // TDA // DPALOO // ATAPFESTIVAL // ATAPCHAMPION
	if($eventid < 1 || ($eventid == 7 || $eventid == 14 || $eventid == 26 || $eventid == 37 || $eventid == 38))
		$authid = "4x7q5DYy";
		$authkey = "463vh6EmNJwz4E83";
	
	 //NUVO
	if($eventid == 8) {
		$authid = "73bAJ4cP";
		$authkey = "5Ay32gZ88Fh32wae";
	}
	
	//24SEVEN
	if($eventid == 18) {
		$authid = "2tY9EdH84";
		$authkey = "8v358ZdwPgvaY59w";
	}
	
	//DTS
	if($eventid == 1) {
		$authid = "9Kq4wbk5WU3S";
		$authkey = "9g5c582PNKmL2e2m";
	}
		
	//RADIX / MAIN EVENT
	if($eventid == 28 || $eventid == 39) {
		$authid = "6fcEu3Ze8W7u";
		$authkey = "8AA4ra67NX8Hd8wh";
	}
?>